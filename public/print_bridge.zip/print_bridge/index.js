const express = require('express');
const cors = require('cors');
const { ThermalPrinter, PrinterTypes } = require('node-thermal-printer');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 8080;

app.post('/print', async (req, res) => {
  try {
    const { folio, branchName, date, items, subtotal, tax, total, method, cashier, footer, width, printerName } = req.body;

    // Configurar la impresora (para desarrollo, usamos interfaz de red o consola)
    // En producción se cambiará 'interface' por 'USB' o 'tcp://IP'
    let printer = new ThermalPrinter({
      type: PrinterTypes.EPSON,
      interface: printerName || 'printer:impresora_termica', // Nombre inyectado desde Configuración
      characterSet: 'PC858_EURO',
      removeSpecialCharacters: false,
      width: width === '58mm' ? 32 : 48 // Ajuste de ancho de papel
    });

    printer.alignCenter();
    try {
      await printer.printImage('./logo.png');
    } catch (err) {
      console.warn('No se pudo cargar el logo:', err);
    }
    printer.println(branchName || 'OmniPOS'); // Header desde configuración
    printer.drawLine();
    
    printer.alignLeft();
    printer.println(`Folio: ${folio}`);
    printer.println(`Fecha: ${new Date(date).toLocaleString()}`);
    printer.println(`Cajero: ${cashier}`);
    printer.drawLine();

    // Productos
    printer.tableCustom([
      { text: 'Cant', align: 'LEFT', width: 0.15 },
      { text: 'Desc', align: 'LEFT', width: 0.5 },
      { text: 'Total', align: 'RIGHT', width: 0.25 }
    ]);
    
    items.forEach(item => {
      printer.tableCustom([
        { text: item.quantity.toString(), align: 'LEFT', width: 0.15 },
        { text: item.product.substring(0, width === '58mm' ? 10 : 15), align: 'LEFT', width: 0.5 },
        { text: `$${item.subtotal.toFixed(2)}`, align: 'RIGHT', width: 0.25 }
      ]);
    });

    printer.drawLine();
    printer.alignRight();
    printer.println(`Subtotal: $${subtotal.toFixed(2)}`);
    printer.println(`IVA: $${tax.toFixed(2)}`);
    printer.println(`Total: $${total.toFixed(2)}`);
    printer.println(`Pago: ${method}`);
    
    printer.drawLine();
    printer.alignCenter();
    if (footer) printer.println(footer);
    
    // Imprimir Código de Barras al final para devoluciones
    if (folio && !folio.includes('OFFLINE')) {
      printer.newLine();
      printer.printBarcode(folio);
    }
    
    // Espacios extra para asegurar que el corte no muerda el código de barras
    // Usamos println(' ') porque algunas impresoras ignoran newLine() al final
    printer.println(' ');
    printer.println(' ');
    printer.println(' ');
    printer.println(' ');
    
    printer.cut();

    // Enviar a impresora real
    await printer.execute();
    
    // También lo imprimimos en consola para confirmación visual
    console.log('--- TICKET ENVIADO A LA IMPRESORA FISICA ---');

    res.status(200).json({ success: true, message: 'Impresión exitosa' });
  } catch (error) {
    console.error('Error al imprimir:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`🖨️  Print Bridge escuchando en http://localhost:${PORT}`);
  console.log(`➡️  Envíe tickets al endpoint POST /print`);
});
